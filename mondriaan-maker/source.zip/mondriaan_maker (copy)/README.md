# Mondriaan Maker
Make art in the abstract style of Piet Mondriaan, which is very accesible for non-artists. Practice your artistic eye for ratio's and color. Uses screen capture addon to export paintings. Palette from: <https://jxapprentice.com/en/art-color-chain-r1-en/>. 
